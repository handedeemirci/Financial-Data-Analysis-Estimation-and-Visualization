#' Result Function
#'
#' This function is used as a helper function by the method `VARModel`. It takes a `varest` object created by `vars::VAR()`
#'as an argument and is necessary for the stepwise backward selection.
#'
#' @param varest A `varest` object created by `vars::VAR()`.
#' @examples
#' quantmod::getSymbols(c("AMZN", "AAPL"), start_date = Sys.Date() - 1000, end_date = Sys.Date())
#' data=cbind(AMZN$AMZN.Adjusted,AAPL$AAPL.Adjusted)
#' varest=vars::VAR(data,p=2,type="none")
#' result(varest)
#' @return A data frame containing all the equations of the `varest` object one below the other
#' @importFrom stats coef
#' @export
result <- function(varest) {
  stopifnot(class(varest) == "varest")
  output <- coef(varest)
  mat_coef <- matrix(nrow = 0, ncol = ncol(output[[1]]))
  for (i in 1:length(output)) {
    mat_coef <- rbind(mat_coef, output[[i]])
  }
  return(mat_coef)
}
