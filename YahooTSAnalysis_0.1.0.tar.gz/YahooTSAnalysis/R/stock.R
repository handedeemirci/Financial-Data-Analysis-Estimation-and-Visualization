#' R6 Class Representing a Stock
#'
#' @description
#' This is an R6 class representing a stock with attributes including ticker (short name for the company),
#' number of observations, dates of the observations, adjusted price time series and logarithmic return of prices.
#' @examples
#' #importation of data
#' quantmod::getSymbols( c("AAPL","AMZN"), start_date = Sys.Date() - 1000, end_date = Sys.Date())
#' AAPL=stock$new(
#' ticker = "AAPL",
#' n_obs = length(as.Date(zoo::index(AAPL))),
#' date = as.Date(zoo::index(AAPL)),
#' adjPrice = as.numeric(quantmod::Cl(AAPL)),
#' logRet = toLogReturn(as.numeric(quantmod::Cl(AAPL))))
#' AMZN=stock$new(
#' ticker = "AMZN",
#' n_obs = length(as.Date(zoo::index(AMZN))),
#' date = as.Date(zoo::index(AMZN)),
#' adjPrice = as.numeric(quantmod::Cl(AMZN)),
#' logRet = toLogReturn(as.numeric(quantmod::Cl(AMZN))))
#'
#' #examples of how to use methods for the class
#' AAPL$descriptive_stat(AAPL$adjPrice,pos1 = 1,pos2 = length(AAPL$date))
#'
#' AAPL$stationarity(AAPL$adjPrice)
#'
#' AAPL$arimaModel(pos1 = 1,pos2 = length(AAPL$date),ord = c(1,1,1))
#'
#' AAPL$garchModel(pos1 = 1,pos2 = length(AAPL$date),ord = c(1,1))
#'
#' data=cbind(AAPL$adjPrice,AMZN$adjPrice)
#' colnames(data)=c("AAPL","AMZN")
#' AAPL$VARModel(data = data,p = 1,n.ahead = 10)
#'
#' ret=cbind(AAPL$logRet,AMZN$logRet)
#' AAPL$portfolioAnalysis(data = ret,expRet = 0.05)
#'
#' @details
#' The stock class allows creating a new stock object with specified attributes and provides a method to visualize
#' the basic descriptive statistics of prices or returns.

#' @export stock
#'
stock <- R6::R6Class(
  "stock",
  public = list(
    #' @field ticker The ticker (short name) for the company.
    ticker = NULL,

    #' @field n_obs The number of observations.
    n_obs = NULL,

    #' @field date The dates of the observations.
    date = NULL,

    #' @field adjPrice The adjusted price time series.
    adjPrice = NULL,

    #' @field logRet The logarithmic return of prices.
    logRet = NULL,


    #' @param ticker Character, the ticker (short name) for the company.
    #' @param n_obs Numeric, the number of observations.
    #' @param date Character vector, the dates of the observations (formatted as "yyyy-mm-dd").
    #' @param adjPrice Numeric vector, the adjusted price time series.
    #' @param logRet Numeric vector, the logarithmic return of prices.
    #' @return A new instance of the stock class.
    initialize = function(ticker, n_obs, date, adjPrice, logRet) {
      stopifnot(is.character(ticker), all(grepl("^[A-Z]+$", ticker)))
      stopifnot(is.numeric(n_obs), length(n_obs) > 0)
      stopifnot(all(grepl("\\d{4}-\\d{2}-\\d{2}", date)), length(date) == n_obs)
      stopifnot(all(is.numeric(adjPrice)))
      stopifnot(all(is.numeric(logRet)))

      self$ticker <- ticker
      self$n_obs <- n_obs
      self$date <- date
      self$adjPrice <- adjPrice
      self$logRet <- logRet

      invisible(self)
    },


    #' @description
    #' Visualizes some basic descriptive statistics of prices or returns.
    #' Moreover are displayed histograms and time-series plot.
    #'
    #' @param values Numeric vector, the adjusted price or logarithmic returns.
    #' @param pos1 Numeric, the index of the first observation to consider. Default is 1.
    #' @param pos2 Numeric, the index of the last observation to consider. Default is equal to the total number of observations.
    #'
    #' @importFrom ggplot2 ggplot aes geom_histogram geom_density geom_line labs theme element_rect after_stat
    #' @importFrom patchwork plot_layout
    #' @exportMethod descriptive_stat
    descriptive_stat = function(values, pos1 = 1, pos2 = self$n_obs) {
      stopifnot(pos2 > pos1, pos1 >= 1, pos2 <= self$n_obs, abs(pos2 - pos1) > 50)
      stopifnot(any(is.numeric(values)))

      if (round(mean(values), 0) == 0) {
        label <- "logarithmic returns"
      } else {
        label <- "prices"
      }

      cat("\nThe mean of", self$ticker, label, "is ", mean(values))
      cat("\nThe standard deviation of", self$ticker, label, "is ", sd(values))
      cat("\nThe skewness of", self$ticker, label, "is ", fBasics::skewness(values))
      cat("\nThe kurtosis of", self$ticker, label, "is ", fBasics::kurtosis(values))

      test <- tseries::jarque.bera.test(values)

      print(test)
      if (test$p.value >= 0.05) {
        cat("\nAccording to Jarque Bera test for", self$ticker, label, ", the hypothesis of normality is accepted")
      } else {
        cat("\nAccording to Jarque Bera test for", self$ticker, label, ", the hypothesis of normality is rejected")
      }
      cat("\n\n")

      p1 <- ggplot(data = as.data.frame(values), aes(x = self$date[pos1:pos2], y = values)) +
        geom_line() +
        labs(title = self$ticker, x = "TIME", y = paste(self$ticker, "", label)) +
        theme(panel.background = element_rect(fill = "light grey"))

      p2 <- ggplot(data = as.data.frame(values), aes(x = values)) +
        geom_histogram(aes(y = after_stat(density)), bins = 30, fill = "steelblue", alpha = 0.7) +
        geom_density(color = "red", linewidth = 1) +
        labs(title = paste("Histogram of", self$ticker, " ", label), y = "Density")

      combined_plot <- (p1 + p2 + plot_layout(ncol = 2, widths = c(1, 1)))
      return(combined_plot)
    },


    #' @description
    #' Visualizes the stationarity.
    #' @importFrom tseries adf.test
    #' @importFrom ggplot2 geom_bar geom_hline ylim
    #' @param values Numeric vector, the adjusted price or logarithmic returns.
    #' @exportMethod stationarity


    stationarity = function(values){
      options(warn=-1)
      stopifnot(any(is.numeric(values)))
      test=adf.test(values) #dickey fuller test applied to the argument passed
      print(test)
      count=0 #counter initialized to zero
      if(test$p.value <= 0.05){
        cat("\nThe time series is stationary")
      }
      while(test$p.value > 0.05){ # repeat the test until the condition is not met.
        count=count+1 #update the counter
        test=adf.test(na.omit(diff(values,differences=count))) #repeat the test differenciating the time series
      }
      #if the time series is not stationary than it is integrated of some order to define.
      #the order is defined by "count"
      if(count != 0){
        cat("\nThe series is integrated of order",count)
      }

      #data related to acf and pacf of the time series until lag 20
      acf_data <- acf(ts(values), lag.max = 20, plot = FALSE)
      pacf_data <- pacf(ts(values), lag.max = 20, plot = FALSE)

      #create a dataframe containing the values of the functions ACF and PACF
      df_acf <- data.frame(lag = acf_data$lag, acf = acf_data$acf)
      df_pacf <- data.frame(lag = pacf_data$lag, pacf = pacf_data$acf)

      #graph in ggplot of acf
      p1=ggplot(df_acf, aes(x = lag, y = acf)) +
        geom_bar(stat = "identity", fill = "steelblue",width = 0.4) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        ylim(-0.25, 1) +
        labs(title = paste0("Auto-correlation function (ACF) of ",self$ticker), x = "Lag", y = "ACF")


      #graph in ggplot of pacf
      p2=ggplot(df_pacf, aes(x = lag, y = pacf)) +
        geom_bar(stat = "identity", fill = "steelblue", width=0.4) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        ylim(-0.25, 1) +
        labs(title = paste0("Partial ACF of ",self$ticker), x = "Lag", y = "PACF")

      #combinantion of the two graphs
      combined_plot = (p1 + p2 + plot_layout(ncol = 2, widths = c(1, 1)))
      return(combined_plot)
    },

    #' @description
    #' Visualizes the ARIMA model
    #'
    #' @param pos1 Numeric, the index of the first observation to consider. Default is 1.
    #' @param pos2 Numeric, the index of the last observation to consider. Default is equal to the total number of observations.
    #' @param ord Vector
    #' @importFrom stats arima0 predict acf pacf
    #' @importFrom ggplot2 geom_ribbon scale_color_manual theme_minimal theme_bw xlab ylab ggtitle
    #' @exportMethod arimaModel

    arimaModel= function(pos1=1,pos2=self$n_obs,ord){
      #some defensive programming
      #the last conditions in order to choose a sufficiently big timespan in order to fit the model properly
      stopifnot(pos2>pos1,pos1>=1,pos2<=self$n_obs,abs(pos2-pos1)>50)
      stopifnot(any(is.numeric(ord)))
      options(warn=-1)
      cat("\n------------- ARIMA(",paste0(ord[1],";",ord[2],";",ord[3],")"),"MODEL FOR",self$ticker,"-------------\n")
      #fitting the model
      fit=arima0(ts(self$adjPrice[pos1:pos2]),order=c(ord[1],ord[2],ord[3]),include.mean = FALSE)
      forecast=predict(fit,n.ahead=20) #evaluating the forecasts 20 step ahead
      #creating the output to display later
      Coefficients <- fit$coef
      Std_err <- sqrt(diag(fit$var.coef))
      z_val=Coefficients/Std_err
      p_val=pnorm(abs(z_val),lower.tail = FALSE)
      print(cbind(Coefficients,Std_err,z_val,p_val))
      cat("\nThe value of log-likelihood is: ",fit$loglik)
      cat("\nThe AIC value is: ",fit$aic)
      cat("\n")


      #create data frame in order to display graphs, it will be displayed the time series
      #and the forecasts done per the future observations with upper and lower bounds
      df=data.frame(adjPrice=tail(self$adjPrice[pos1:pos2],200),
                    time=tail(self$date[pos1:pos2],200),
                    pred=c(rep(0,180),forecast$pred),
                    se=c(rep(0,180),forecast$se))
      df_pred <- df[df$pred != 0, ]
      p1= ggplot(df, aes(x = time)) +
        geom_line(aes(y = adjPrice, color = "Actual")) +
        geom_line(data = df_pred, aes(y = pred, color = "Forecast")) +
        geom_ribbon(aes(ymin = pred - 1.96 * se, ymax = pred + 1.96 * se), alpha = 0.2, fill = "yellow", color = NA) +
        labs(x = "Time", y = paste("Adjusted Price of",self$ticker), color = "") +
        scale_color_manual(values = c("Actual" = "blue", "Forecast" = "red")) +
        theme_minimal()




      #graphs of the residuals (errors) of the model, the should be with zero mean
      p2=ggplot(data.frame(residuals = fit$residuals), aes(x = seq_along(residuals), y = residuals)) +
        geom_line() +
        geom_hline(yintercept = mean(fit$residuals), color = "red") +
        labs(x = "Observation", y = "Residual", title = "Residual Plot") +
        theme_minimal()



      residuals <- residuals(fit)
      acf_resid <- acf(residuals,plot = FALSE)

      #acf for residuals of the model in order to give a goodness of fit for the model
      conf_level <- 1.96/sqrt(length(residuals))
      acf_resid_df <- data.frame(lag = acf_resid$lag, acf = acf_resid$acf, conf_level = conf_level)
      acf_resid_df <- acf_resid_df[acf_resid_df$acf > acf_resid_df$conf_level | acf_resid_df$acf < -acf_resid_df$conf_level,]


      p3=ggplot(data = acf_resid_df, aes(x = lag, y = acf)) +
        geom_bar(stat = "identity", width=0.3, fill = "grey50") +
        geom_hline(yintercept = conf_level, linetype = "dashed") +
        geom_hline(yintercept = -conf_level, linetype = "dashed") +
        ylim(-1, 1) +
        xlab("Lag") +
        ylab("Autocorrelation") +
        ggtitle("ACF of Residuals") +
        theme_bw()



      # invisible(self)
      # combine the plot
      combined_plot = (p1 / (p2 + p3)) + plot_layout(ncol = 1)
      return(combined_plot)
    },
    #' @description
    #' Visualizes the GARCH model
    #'
    #' @param pos1 Integer, the index of the first observation to consider. Default is 1.
    #' @param pos2 Integer, the index of the last observation to consider. Default is equal to the total number of observations.
    #' @param ord Vector of integers that corresponds to the order of the ARIMA (p,d,q) model
    #' @importFrom rugarch ugarchspec ugarchfit ugarchforecast sigma
    #' @return A combined plot of ACF and PACF of squared returns, the conditional variance over the time
    #' and the ACF of squared standardized residuals
    #' @exportMethod garchModel
    garchModel=function(pos1=1,pos2=self$n_obs,ord){
      #some defensive programming
      #the last conditions in order to choose a sufficiently big timespan in order to fit the model properly
      stopifnot(pos2>pos1,pos1>=1,pos2<=self$n_obs,abs(pos2-pos1)>50)
      stopifnot(any(is.numeric(ord)))
      options(warn=-1)
      acf_data <- acf(ts((self$logRet[pos1:pos2])^2), lag.max = 20, plot = FALSE)
      pacf_data <- pacf(ts((self$logRet[pos1:pos2])^2), lag.max = 20, plot = FALSE)

      df_acf <- data.frame(lag = acf_data$lag, acf = acf_data$acf)
      df_pacf <- data.frame(lag = pacf_data$lag, pacf = pacf_data$acf)

      p1=ggplot(df_acf, aes(x = lag, y = acf)) +
        geom_bar(stat = "identity", fill = "steelblue",width = 0.4) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        ylim(0, 1) +
        labs(title = paste0("ACF of squared log-return of ",self$ticker), x = "Lag", y = "ACF")


      p2=ggplot(df_pacf, aes(x = lag, y = pacf)) +
        geom_bar(stat = "identity", fill = "steelblue", width=0.4) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        ylim(0, 1) +
        labs(title = paste0("Partial ACF of squared log-return of ",self$ticker), x = "Lag", y = "PACF")

      #specification of the model
      spec <- ugarchspec(variance.model = list(model = "sGARCH", garchOrder = c(ord[1], ord[2])),
                         mean.model = list(armaOrder = c(0, 0), include.mean = FALSE),
                         distribution.model = "norm")
      cat("\n------------- GARCH(",paste0(ord[1],";",ord[2],")"),"MODEL FOR",self$ticker,"-------------\n")
      #fitting of the model
      fit <- ugarchfit(spec = spec, data = self$logRet[pos1:pos2])


      print(fit@fit$matcoef)

      forecasts <- ugarchforecast(fit, n.ahead = 20)


      p3 =ggplot() +
        geom_line(aes(x = index(self$date[pos1:pos2]), y = sigma(fit))) +
        labs(title = "Conditional variance over the time", x = "Time", y = "
         Value of conditional variance")

      resStdSq=fit@fit$residuals/(sqrt(fit@fit$sigma))



      acf_data <- acf(ts((resStdSq)^2), lag.max = 20, plot = FALSE)
      pacf_data <- pacf(ts((resStdSq)^2), lag.max = 20, plot = FALSE)

      df_acf <- data.frame(lag = acf_data$lag, acf = acf_data$acf)
      df_pacf <- data.frame(lag = pacf_data$lag, pacf = pacf_data$acf)

      p4=ggplot(df_acf, aes(x = lag, y = acf)) +
        geom_bar(stat = "identity", fill = "steelblue",width = 0.4) +
        geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
        ylim(0, 1) +
        labs(title = paste0("ACF of squared standardized residuals of the model"),
             x = "Lag", y = "ACF")


      combined_plot = ((p1 + p2) /(p3 +p4) + plot_layout(ncol = 1))
      return(combined_plot)
    },

    #' @description
    #' Visualizes the VAR model
    #'
    #' @param data matrix containing the data to analyse. Must have more than one column.
    #' @param p Integer, is the order of the VAR to fit.
    #' @param n.ahead Integer, is the number of step ahead to perform the Impulse Response Function.
    #' @importFrom vars roots causality irf
    #' @importFrom patchwork wrap_plots
    #' @return The output of the VAR model with selection of significant parameters, the output
    #' of Granger causality test and the graphs of the IRF (Impulse Response Function).
    #' @exportMethod VARModel
    VARModel=function(data,p,n.ahead){
      options(warn=-1)
      k=ncol(data)

      varest=vars::VAR(data,p=p,type = "none")#fitting the model
      var_rid=stepwise_back(varest,p=p,k)#this function make the stepwise backward
      for(i in 1:k){#printing the output equation by equation
        cat("\nEstimated equation (with significant parameters selection) for ",colnames(data)[i],"\n")
        print(coef(var_rid)[[i]])#this is a list of lists
        cat("\n")
      }
      cat("\n")
      cat("\nVariance and covariance matrix: \n")
      print(summary(var_rid)$covres)
      #check for model stationarity
      cat("\n\nModules of roots of the VAR model fitted:",1/Mod(roots(var_rid)))
      if(sum(1/Mod(roots(var_rid)) <=1)){
        cat("\nThe VAR model is NOT stationary\n")
      }else{
        cat("\nThe VAR model is stationary\n")
      }

      for(i in 1:k){
        test=causality(x = var_rid,cause = colnames(data)[i])$Granger
        if(test$p.value<=0.05){
          cat("\n",colnames(data)[i], "cause (",colnames(data)[-i],") according to Granger causality")
        }else{
          cat("\n",colnames(data)[i], "do not cause (",colnames(data)[-i],") according to Granger causality")
        }
      }


      irf=irf(var_rid,n.ahead = n.ahead,ortho = TRUE)

      irf_data <- irf$irf[[1]]
      colnames(irf_data)=colnames(data)
      #plotting the IRF
      irf_df <- data.frame(x = rep(seq(nrow(irf_data)), ncol(irf_data)),
                           y = as.vector(irf_data),
                           variable = rep(colnames(irf_data), each = nrow(irf_data)))
      p <- ggplot(irf_df, aes(x = x, y = y, color = variable)) +
        geom_line(linewidth= 1.0) +
        labs(title = paste("Impulse Response Functions from ",colnames(data)[1]))

      for(i in 2:k){
        irf_data <- irf$irf[[i]]
        colnames(irf_data)=colnames(data)
        irf_df <- data.frame(x = rep(seq(nrow(irf_data)), ncol(irf_data)),
                             y = as.vector(irf_data),
                             variable = rep(colnames(irf_data), each = nrow(irf_data)))

        p <- p + ggplot(irf_df, aes(x = x, y = y, color = variable)) +
          geom_line(linewidth= 1.0) +
          labs(title = paste("Impulse Response Functions from ",colnames(data)[i]))

      }
      #combine the plots
      p <- p + plot_layout(ncol = 2)

      plotcomb=wrap_plots(p)
      return(plotcomb)
    },

    #' @description
    #' Perform the Markovitz model for portfolio analysis
    #' @importFrom ggplot2 geom_path geom_point scale_x_continuous
    #' @param data matrix containing the data to take in account.
    #' @param expRet Numeric, is the expected return the user want to get by the optimisation.
    #' @return The output of the Markovitz model with the weights for each stock take in consideration,
    #' negative weights suggest short selling while positive weight buying. Moreover the efficient frontier
    #' graph is displayed.
    #' @exportMethod portfolioAnalysis
    portfolioAnalysis=function(data,expRet){
      stopifnot(all(is.numeric(data)))
      stopifnot(is.numeric(expRet) & length(expRet)==1)
      N <- ncol(data)
      mu <- colMeans(data)
      Sigma <- var(data)
      A <- t(rep(1,N))%*%solve(Sigma)%*%mu
      B <- t(rep(1,N))%*%solve(Sigma)%*%rep(1,N)
      C <- t(mu)%*%solve(Sigma)%*%mu
      D <- A^2-B*C
      A <- as.vector(A)
      B <- as.vector(B)
      C <- as.vector(C)
      D <- as.vector(D)
      lambda1 <- as.vector((A-B*expRet)/D)
      lambda2 <- as.vector((A*expRet-C)/D)

      w.ott <- as.vector(lambda1*solve(Sigma)%*%mu+lambda2*solve(Sigma)%*%rep(1,N))

      frontier <- function(mu.bar) {
        -B/D * mu.bar^2 + 2*A/D * mu.bar - C/D
      }
      res=rbind(colnames(data),round(w.ott,4))
      cat("\nThe weights for each titles are: \n")
      write.table(res, quote = FALSE, row.names = FALSE,col.names = FALSE)
      cat("\nThe expected return is ",t(w.ott)%*%mu)
      cat("\nThe variance is ",t(w.ott)%*%Sigma%*%w.ott) #quantification of the risk

      mu.bar <- seq(0.0001, 0.15, length = 10000)

      #creating the graph
      df <- data.frame(mu.bar, frontier(mu.bar))

      p1=ggplot(df, aes(x = sqrt(frontier(mu.bar)), y = mu.bar)) +
        geom_path(color = "black", size = 1) +
        geom_point(data = data.frame(x = c(sqrt(diag(Sigma)),sqrt(1/B)), y = c(colMeans(data), A/B)),
                   aes(x = x, y = y), color = c(rep("light green",ncol(data)),"orange"), size = 3, shape = 16) +
        scale_x_continuous(limits = c(0, 10)) +
        xlab(expression(sigma[p])) +
        ylab("Expected return")
      return(p1)
    }



  )

)
