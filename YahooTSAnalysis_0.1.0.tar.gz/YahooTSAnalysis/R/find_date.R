#' Find Nearest Date
#'
#' This function finds the nearest date in a vector of dates to a given input date.
#'
#' @param input_date A date in the format "yyyy/mm/dd" chosen by the user.
#' @param date_vec A vector of dates corresponding to the dates of downloaded data.
#' @return The nearest date in the \code{date_vec} to the \code{input_date}. If one date is equidistant
#' from two dates in the date_vec then it would be returned the more recent date.
#' @examples
#' date_vector <- c("2023-01-01", "2023-01-03", "2023-01-05")
#' input_date <- "2023-01-02"
#' nearest_date <- find_nearest_date(input_date, date_vector)
#' print(nearest_date) # Output: "2023-01-03"
#' @export
find_nearest_date <- function(input_date, date_vec) {
  stopifnot(all(grepl("\\d{4}-\\d{2}-\\d{2}", date_vec)))
  stopifnot(grepl("\\d{4}-\\d{2}-\\d{2}", input_date))
  stopifnot(length(input_date) == 1)

  nearest_index <- which.min(abs(as.numeric(date_vec) - as.numeric(input_date)))
  return(date_vec[nearest_index])
}
