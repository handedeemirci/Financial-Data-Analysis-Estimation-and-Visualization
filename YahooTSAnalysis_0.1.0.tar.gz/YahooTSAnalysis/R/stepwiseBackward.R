#' Stepwise Backward Selection Function
#'
#' This function performs stepwise backward selection on a full fitted VAR model. It takes the following arguments:
#'
#'
#' The function iteratively removes non-significant parameters (if present) from the VAR model until all remaining parameters are significant.
#' It returns the reduced VAR model.
#'
#' @param varest The full VAR model with non-significant parameters.
#' @param p The order of the VAR model.
#' @param k The number of columns of the data.
#' @return A varest object that corresponds to the reduced VAR model after stepwise backward selection.
#' @examples
#' quantmod::getSymbols(c("AMZN", "AAPL"), start_date = Sys.Date() - 1000, end_date = Sys.Date())
#' data=cbind(AMZN$AMZN.Adjusted,AAPL$AAPL.Adjusted)
#' p=2
#' varest=vars::VAR(data,p,type="none")
#' var_reduced=stepwise_back(varest,p,k=ncol(data))
#' @importFrom vars restrict VAR
#' @export
stepwise_back <- function(varest, p, k) {
  stopifnot(class(varest) == "varest")
  stopifnot(p >= 0 | k >= 1)

  mat_coef_st <- result(varest)  # recall to the result function
  p_val <- mat_coef_st[, 4]  # selection of the p value
  pos_diag <- seq(1, k * k * p, by = k * p + 1)  # position of the variables not to remove
  pos <- which(p_val >= 0.1 & !p_val %in% p_val[pos_diag])  # position of the variables to remove
  mat_coef_st[pos, ] <- 0  # set the lines as zero

  mat_par <- matrix(mat_coef_st[, 1], k, k * p, byrow = TRUE)  # order in a matrix
  mat_restr <- ifelse(mat_par != 0, 1, 0)  # build the matrix restriction of 1 and 0
  var_rid <- vars::restrict(varest, method = "man", resmat = mat_restr)

  count <- length(pos)  # number of parameters removed so far

  while (length(pos) != 0) {
    # redo until the condition is met (all the parameters are significant)
    mat_coef <- result(var_rid)
    righe_sost <- apply(mat_coef_st, 1, function(x) !all(x == 0))
    mat_coef_st[righe_sost, ] <- mat_coef

    p_val <- mat_coef_st[, 4]
    pos_diag <- seq(1, k * k * p, by = k * p + 1)
    pos <- which(p_val == max(p_val[p_val >= 0.05 & !p_val %in% p_val[pos_diag]]))
    mat_coef_st[pos, ] <- 0

    mat_par <- matrix(mat_coef_st[, 1], k, k * p, byrow = TRUE)
    mat_restr <- ifelse(mat_par != 0, 1, 0)
    var_rid <- vars::restrict(varest, method = "man", resmat = mat_restr)
    count <- count + 1
  }

  cat("\nBy the stepwise backward,", count-1, "parameters have been removed over", k * p * k)
  return(var_rid)
}
