#' Function that creates log-returns from prices
#'
#' This function calculates the log-returns from a vector of prices.
#'
#' @param prices A numeric vector of prices.
#' @return A numeric vector of log-returns.
#' @export
#' @examples
#' prices <- c(10, 12, 15, 13, 11)
#' log_returns <- toLogReturn(prices)
#' print(log_returns)
#'
#'
toLogReturn <- function(prices) {
  stopifnot(all(is.numeric(prices)),all(prices>0))
  logRet <- 100 * c(mean(diff(log(prices))), diff(log(prices)))
  return(logRet)
}
