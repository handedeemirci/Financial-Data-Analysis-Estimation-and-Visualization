#' Import Data from Yahoo Finance
#'
#' This function imports stock data from Yahoo Finance for the given tickers and date range.
#'
#' @param tickers A character vector of stock tickers to import.
#' @param start_date The start date of the data in the format "yyyy-mm-dd".
#' @param end_date The end date of the data in the format "yyyy-mm-dd".
#'
#' @details The function extract data (close price) of the tickers from Yahoo Finance.
#' After that put the data in a R6 class object called "stock".
#'
#' The function retrieves stock data using the getSymbols function from the quantmod package,
#' and creates a stock object for each ticker with the following attributes:
#' - ticker: The stock ticker.
#' - n_obs: The number of observations downloaded.
#' - date: A vector of dates corresponding to the data.
#' - adjPrice: A vector of adjusted closing prices.
#' - logRet: A vector of log returns calculated from the adjusted closing prices.
#'
#' The stock objects are assigned to the global environment with the ticker name as the variable name.
#' @examples
#' importData(tickers = c("AMZN", "AAPL"), start_date = Sys.Date() - 1000, end_date = Sys.Date())
#' head(AAPL$date)
#' # Retrieve stock data for AMZN and AAPL from the past 1000 days.
#' # Stock objects named "AMZN" and "AAPL" will be created in the global environment.
#'
#' @return NULL
#' @importFrom quantmod getSymbols Cl
#' @importFrom purrr map
#' @importFrom zoo index
#' @export
#'
#'
importData <- function(tickers, start_date, end_date) {
  stopifnot(all(is.character(tickers)))
  stopifnot(all(nchar(tickers) >= 1))
  stopifnot(all(grepl("^[A-Z]+$", tickers)))
  stopifnot(grepl("\\d{4}-\\d{2}-\\d{2}", start_date))
  stopifnot(grepl("\\d{4}-\\d{2}-\\d{2}", end_date))

  invisible(map(tickers, function(i) {
    getSymbols(i, src = "yahoo", from = start_date, to = end_date)
    stock <- stock$new(
      ticker = i,
      n_obs = length(as.Date(index(get(i)))),
      date = as.Date(index(get(i))),
      adjPrice = as.numeric(Cl(get(i))),
      logRet = toLogReturn(as.numeric(Cl(get(i))))
    )
    assign(i, stock, envir = globalenv())
  }))
}
